### What steps will reproduce the problem?

### What's expected?

### What do you get instead?


### Additional info

| Q                | A
| ---------------- | ---
| Yii vesion       |
| PHP version      |
| Operating system |
