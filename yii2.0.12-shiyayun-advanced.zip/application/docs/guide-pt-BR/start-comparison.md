Comparativo
===========

A tabela a seguir faz um comparativo entre o template de projetos básico e avançado:

| Funcionalidade |  Básico  | Avançado |
|---|:---:|:---:|
| Estrutura do projeto | ✓ | ✓ |
| Controller do site | ✓ | ✓ |
| Login/logout de usuários | ✓ | ✓ |
| Formulários | ✓ | ✓ |
| Conexão com BD | ✓ | ✓ |
| Comando de console | ✓ | ✓ |
| Asset bundle | ✓ | ✓ |
| Testes com Codeception | ✓ | ✓ |
| Twitter Bootstrap | ✓ | ✓ |
| Aplicações front e back-end |    | ✓ |
| Model de usuário pronto para uso |    | ✓ |
| Registro de usuários e recuperação de senha |     | ✓ |