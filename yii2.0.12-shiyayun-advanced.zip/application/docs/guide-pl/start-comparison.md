Różnice pomiędzy szablonami
===========================

Poniższa tabela pokazuje, które funkcjonalności dostępne są w podstawowym i zaawansowanym szablonem projektu:


| Funkcjonalność  |  Podstawowy  |  Zaawansowany |
|---|:---:|:---:|
| Struktura projektu | ✓ | ✓ |
| Główny kontroler strony | ✓ | ✓ |
| Logowanie użytkownika | ✓ | ✓ |
| Formularze | ✓ | ✓ |
| Połączenie z bazą danych | ✓ | ✓ |
| Polecenia konsoli | ✓ | ✓ |
| Pakiety assetów | ✓ | ✓ |
| Testy Codeception | ✓ | ✓ |
| Twitter Bootstrap | ✓ | ✓ |
| Aplikacja front i back-endowa |    | ✓ |
| Gotowy model użytkownika |    | ✓ |
| Rejestracja i przywracanie hasła użytkownika |     | ✓ |
