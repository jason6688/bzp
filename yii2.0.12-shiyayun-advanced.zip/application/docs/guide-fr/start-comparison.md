Comparaison
===========

La table ci-dessous présente les différences entre le modèle de projet avancé et le modèle de projet *basic* :


| Fonctionnalité  |  *Basic*  |  *Advanced* |
|---|:---:|:---:|
| Structure du projet | ✓ | ✓ |
| Contrôleur *site* | ✓ | ✓ |
| Connexion/déconnexion du l'utilisateur | ✓ | ✓ |
| Formulaires  | ✓ | ✓ |
| Connexion à la base de données  | ✓ | ✓ |
| Commandes en console  | ✓ | ✓ |
| Paquets de ressources  | ✓ | ✓ |
| Tests Codeception  | ✓ | ✓ |
| Twitter Bootstrap  | ✓ | ✓ |
| Applications *frontend*/*backend*  |    | ✓ |
| Modèle utilisateur prêt à l'emploi |    | ✓ |
| Enregistrement de l'utilisateur et récupération du mot de passe |     | ✓ |
